# segmentation_road > 2023-03-31 7:16pm
https://universe.roboflow.com/image-segmentation-awhml/segmentation_road

Provided by a Roboflow user
License: CC BY 4.0

